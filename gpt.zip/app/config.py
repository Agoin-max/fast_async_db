from pydantic import RedisDsn
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """配置."""

    OCR_ACCOUNT: str = "admin"
    OCR_PASSWORD: str = "admin20231028"
    OCR_PROJECT: int = 5
    OCR_TIMEOUT: int = 300

    # OPENAI_API_KEY: str = "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"
    # BASE_URL: str = "https://oigai.oigit.com/v1"
    # ASSISTANT_ID: str = "asst_Dy0sFuxiXPLvEnuoAbdpUsmu"

    OPENAI_API_KEY: str = "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"
    BASE_URL: str = "https://ioigai.oigit.com/v1"
    ASSISTANT_ID: str = "asst_E8OuGudRHL8mittaTgj0Dxmw"

    DOCUMENT_BASE_URL: str = "http://docs.local.oigit.com"
    DOCUMENT_TOKEN: str = "1e24685a12958a28d8185aaa65f589e8a7aed768b8d243bbdebc3607"

    RADIO_SCORE: float = 0.4
    WORD_LIMIT: int = 512

    XFYUN_APP_ID: str = "62bc048c"
    XFYUN_API_SECRET: str = "NjM1MDY0NzYwNTcwY2ViY2E3ZjY2ZWJl"
    XFYUN_API_KEY: str = "a117102f0df6fca842111147baf329a3"
    XFYUN_IMAGE_URL: str = "wss://spark-api.cn-huabei-1.xf-yun.com/v2.1/image"
    XFYUN_SCEN_URL: str = "http://tupapi.xfyun.cn/v1/scene"  # 分辨场景

    MILVUS_HOST: str = "192.168.186.165"
    MILVUS_PORT: str = "19530"
    COLLECTION_NAME: str = "factory_v3"

    # redis
    REDIS_URL: RedisDsn = "redis://192.168.186.165:6379/6"


settings = Settings()
