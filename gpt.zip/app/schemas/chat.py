from typing import List, Optional

from pydantic import BaseModel, Field


class MessageRequest(BaseModel):
    """Message Request."""

    session_id: str = Field("", title="会话ID")
    query: str = Field("", title="问题")
    attachment: Optional[List] = Field([], title="附件Url")
