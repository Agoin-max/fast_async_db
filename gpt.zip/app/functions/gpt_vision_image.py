import base64

import requests
from openai import OpenAI

from config import settings

client = OpenAI(api_key=settings.OPENAI_API_KEY, base_url=settings.BASE_URL)


# 这是一份文档吗?你的回答只有两种选项：'是'或者'不是'，字数控制在两个字内
def client_gpt(url: str, question: str):
    """连接gpt."""
    try:
        res = requests.get(url, timeout=300)
        response = client.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": question},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64.b64encode(res.content).decode()}"
                            },
                        },
                    ],
                }
            ],
            max_tokens=2000,
        )
        return response.choices[0].message.content
    except Exception as ex:
        print(ex)
        return "不是"
