import torch
from punctuators.models.punc_cap_seg_model import (
    PunctCapSegConfigONNX,
    PunctCapSegModelONNX,
)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class FixPunctuation:
    """修正标点符号."""

    USE_ZH_PUNCTUATION = [
        "，",
        "、",
        "。",
        "？",
        "！",
        "；",
    ]
    # !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
    fix_punctuation = {".", ",", ";", "?", "!"} | set(USE_ZH_PUNCTUATION)

    def __init__(
        self,
        model_name: str = "punct_cap_seg_47_language",
        window_size: int = 512,
        step: int = 32,
    ):
        """初始化函数."""
        self.step = step
        self.window_size = window_size
        self.model = PunctCapSegModelONNX(
            PunctCapSegConfigONNX(
                # hf_repo_id="1-800-BAD-CODE/punct_cap_seg_47_language",
                spe_filename="spe_unigram_64k_lowercase_47lang.model",
                model_filename="punct_cap_seg_47lang.onnx",
                directory=model_name,
            )
        )

    def predict(self, text: str):
        """推理文本."""
        for from_ in self.fix_punctuation:
            text = text.replace(from_, "")

        predict_tokens = self.model.infer([text])
        rrr = "".join(predict_tokens[0])
        return rrr.replace("<Unk>", " ").replace("<unk>", " ").strip()


def main():
    """主函数."""
    fix_punc = FixPunctuation(window_size=32, step=16)
    for text in [
        "你好啊,我是中国人",
        "你好啊我是中国人",
        "你好啊，我是中国人",
        "你好啊，我是中国人,",
        "你好啊，我是中国人。",
        "how old are you",
        "how old are you how do you do",
        "how old are you, how do you do",
        "how old are you? how do you do?",
        "你好啊，i am chinese, 我是中国人。",
        (
            "文章1984年出生于陕西省西安市。上高三的时候，文章被保送到四川师范大学艺术学院学习影视表演，但是他并未进入这个学校，而是决心去北京学习。"
            "在填写大学志愿之前，文章专门去北京考察了中国两大艺术院校—北京电影学院和中央戏剧学院。"
            "回到西安之后，文章不顾父母阻拦，将大学志愿从一本到专科总共八个志愿全部填成中央戏剧学院。2002年文章被中央戏剧学院表演系录取。"
        ),
    ]:
        data = fix_punc.predict(text)
        print(data, len(text) - len(data))


if __name__ == "__main__":
    main()
