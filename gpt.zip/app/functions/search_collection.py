import logging

from langchain.embeddings.huggingface import HuggingFaceBgeEmbeddings
from langchain.vectorstores.milvus import Milvus
from openai import AsyncOpenAI

from config import settings

logger = logging.getLogger("uvicorn.error")

MILVUS_HOST = settings.MILVUS_HOST
MILVUS_PORT = settings.MILVUS_PORT
COLLECTION_NAME = settings.COLLECTION_NAME


embeddings = HuggingFaceBgeEmbeddings(
    model_name="./models/embeddings/bge-large-zh",
    encode_kwargs={"normalize_embeddings": True},
)


db = Milvus(
    # documents,
    embedding_function=embeddings,
    collection_name=COLLECTION_NAME,
    connection_args={"host": MILVUS_HOST, "port": MILVUS_PORT},
    index_params={
        "metric_type": "L2",
        "index_type": "IVF_FLAT",
        "params": {"nlist": 2048},
    },
)


_PROMPT_TEMPLATE = """According the content to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer.Please use the chinese to answer the question.

This should be in the following format:

Question: [question here]
Helpful Answer: [answer here]

Example #1

Content:
---------
苹果是红色的
---------
Question: 苹果是什么颜色的?
Helpful Answer: 苹果是红色的

Example #2

Content:
---------
当时是晚上，目击者忘记戴眼镜了.他不确定这是跑车还是SUV.
---------
Question: 是什么类型的车?
Helpful Answer: 跑车或者是suv

Example #3

Content:
---------
梨是红色或者橙色的
---------
Question: 苹果是什么颜色的?
Helpful Answer: 暂时不能回答这个问题


Example #4

Content:
---------
巴西4444的在华注册生产企业信息?
企业名称: LAR COOPERATIVA AGROINDUSTRIAL
所属国家: 巴西
所属国家注册编码: SIF4444
在华注册编码: CBRA01051808010028
批准品类: 禽肉产品
注册日期: 2018-08-01
注册有效日期: 2028-07-31
企业地址: BR 277, KM 653, BAIRRO: DISTRITO DE AGROCAFEEIRA - CEP 85887-000 Matelândia - Parana
---------
Question: 巴西4444
Helpful Answer: 企业名称: LAR COOPERATIVA AGROINDUSTRIAL
                所属国家: 巴西
                所属国家注册编码: SIF4444
                在华注册编码: CBRA01051808010028
                批准品类: 禽肉产品
                注册日期: 2018-08-01
                注册有效日期: 2028-07-31
                企业地址: BR 277, KM 653, BAIRRO: DISTRITO DE AGROCAFEEIRA - CEP 85887-000 Matelândia - Parana

Begin!

Content:
---------
{content}
---------
Question: {question}
Helpful Answer:"""


async def search_doc(model_client: AsyncOpenAI, content: str, input_question: str):
    """查询doc."""
    response = await model_client.chat.completions.create(
        model="gpt-4-1106-preview",
        messages=[
            {
                "role": "user",
                "content": _PROMPT_TEMPLATE.format(
                    **{
                        "content": content,
                        "question": input_question,
                    }
                ),
            }
        ],
    )
    return response.choices[0].message.content


async def search_factory(client: AsyncOpenAI, question: str, page: int = 0):
    """查询工厂."""
    param = {}
    if page:
        param = {"offset": (int(page) - 1) * 5}

    docs = db.similarity_search(question, k=5, param=param)

    all_content = []
    for item in docs:
        logger.info(item.page_content)
        content = "\n".join([item.page_content, item.metadata["answer"]])

        all_content.append(content)

    content = "\n\n".join(all_content)
    logger.info("长度: %s", len(content))

    content = "\n\n".join(all_content)
    if content:
        return content

    return "我的资料库中暂时还未找到答案,我已做好了记录,我将会继续学习"
