import torch
from transformers import AutoModelForTokenClassification, AutoTokenizer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class FixPunctuation:
    """修正标点符号."""

    USE_ZH_PUNCTUATION = [
        "，",
        "、",
        "。",
        "？",
        "！",
        "；",
    ]
    # !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
    fix_punctuation = {".", ",", ";", "?", "!"} | set(USE_ZH_PUNCTUATION)

    def __init__(
        self,
        model_name: str = "models/punctuation/zh-wiki-punctuation-restore",
        window_size: int = 512,
        step: int = 32,
    ):
        """初始化函数."""
        self.step = step
        self.window_size = window_size
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForTokenClassification.from_pretrained(model_name).to(
            device
        )

    def token_stride(self, text_: str):
        """切割文本."""

        def token_stride_(text_: str):
            tokens = list(text_)
            for start_ in range(0, len(tokens), self.step):
                window_tokens = tokens[start_ : start_ + self.window_size]
                tokens_ = self.tokenizer.convert_tokens_to_ids(window_tokens)

                # padding
                while len(tokens_) < self.window_size:
                    tokens_.append(self.tokenizer.pad_token_id)

                yield tokens_

        return torch.tensor([tokens for tokens in token_stride_(text_)], device=device)

    def predict(self, text: str):
        """推理文本."""
        # for from_ in self.fix_punctuation:
        #     text = text.replace(from_, "")

        def predict_(text: str):
            batch_out = []
            batchs = self.token_stride(text)
            batch_input_ids = batchs
            encodings = {"input_ids": batchs}
            output = self.model(**encodings)
            predicted_token_class_id_batch = output["logits"].argmax(-1)

            for index, (predicted_ids, input_ids) in enumerate(
                zip(predicted_token_class_id_batch, batch_input_ids)
            ):
                out = []
                tokens = self.tokenizer.convert_ids_to_tokens(input_ids)
                # predicted_token_class_ids
                predicted_tokens = [
                    self.model.config.id2label[t.item()] for t in predicted_ids
                ]

                # compute the pad start in input_ids
                # and also truncate the predict
                # print(tokenizer.decode(batch_input_ids))
                input_ids = input_ids.tolist()
                try:
                    input_id_pad_start = input_ids.index(self.tokenizer.pad_token_id)
                except ValueError:
                    input_id_pad_start = len(input_ids)

                if index > 0:
                    index_start = self.step
                else:
                    index_start = 0

                # unpadding
                input_ids = input_ids[index_start:input_id_pad_start]
                tokens = tokens[index_start:input_id_pad_start]
                predicted_tokens = predicted_tokens[index_start:input_id_pad_start]

                for token, ner in zip(tokens, predicted_tokens):
                    # TODO - 不是很恰当的做法,主要是空格符被认定非法字符
                    if token == self.tokenizer.unk_token:
                        token = " "

                    # yield (token, ner)
                    out.append((token, ner))

                batch_out.extend(out)
            return batch_out

        out_tokens = []
        predict_tokens = predict_(text)
        predict_tokens_limit = len(predict_tokens) - 1
        for index, (token, ner) in enumerate(predict_tokens):
            out_tokens.append(token)
            if ner != "O":
                # 本身是标点符号,无需追加
                if token in self.fix_punctuation or (
                    index < predict_tokens_limit
                    and predict_tokens[index + 1][0] in self.fix_punctuation
                ):
                    continue

                out_tokens.append(ner[-1])

        return "".join(out_tokens[:-1] if out_tokens[-1] == "。" else out_tokens)


def main():
    """主函数."""
    fix_punc = FixPunctuation(window_size=32, step=16)
    for text in [
        "你好啊,我是中国人",
        "你好啊我是中国人",
        "你好啊，我是中国人",
        "你好啊，我是中国人,",
        "你好啊，我是中国人。",
        "how old are you",
        "how old are you how do you do",
        "how old are you, how do you do",
        "how old are you? how do you do?",
        "你好啊，i am chinese, 我是中国人。",
    ]:
        data = fix_punc.predict(text)
        print(data, len(text) - len(data))


if __name__ == "__main__":
    main()
