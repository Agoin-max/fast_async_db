import asyncio
import json
import logging
import os
import time

import aiohttp

from app.config import settings

OCR_ACCOUNT = settings.OCR_ACCOUNT
OCR_PASSWORD = settings.OCR_PASSWORD
OCR_PROJECT = settings.OCR_PROJECT

logger = logging.getLogger("uvicorn.main")


_PROMPT_TEMPLATE = """
The user will ask a question about document field and document type. You should understand the question, find the relevant content in the following information, and reply to the relevant question in Chinese.

You will be able to get the specific document type and a list of all fields that were successfully parsed.If the question is not about document field and document type, you should reply all the parse infomation to user.

example:

Document type "invoice"

The document field is in Json format. Please parse out the corresponding field:

```json
{{
    "price": "1000",
    "invoice_no": "9999999",
}}
```

Begin! You will get relevant data.

Document type "{label}"

The document field is in Json format. Please parse out the corresponding field:

```json
{{
    {fields}
}}
```

Please reply to the question based on the above information. Please translate the final reply into Chinese.

Input: {question}
"""


class LoginInvaild(Exception):
    """登录无效."""


def hook_logged(func):
    """登录钩子."""
    MAX_RETRY = 5

    async def wrap(self, *args, **kwargs):
        retry_count = 0
        if "retry_count" in kwargs:
            retry_count = int(kwargs.pop("retry_count"))

        if retry_count > MAX_RETRY:
            raise TypeError("登录达到最大重试次数")

        await self.login_when_not_token()

        try:
            rsp = await func(self, *args, **kwargs)
        except LoginInvaild:
            logger.info("登录失败重试 %s", retry_count)
            await asyncio.sleep(1)
            self.reset_token()
            kwargs["retry_count"] = retry_count + 1
            return await wrap(self, *args, **kwargs)
        except Exception as ex:
            logger.warning("请求异常 %s", ex)
            raise ex
        else:
            return rsp

    return wrap


class Token(str):
    """登录信息."""

    TOKEN_PATH = os.path.join(os.getcwd(), "ocr_token.dat")

    def save(self):
        """保存Token."""
        with open(self.TOKEN_PATH, "w", encoding="utf8") as fs:
            fs.write(self)

    @classmethod
    def load(cls):
        """加载Token."""
        data = ""
        try:
            with open(cls.TOKEN_PATH, "r", encoding="utf8") as fs:
                data = fs.read()
        finally:
            return cls(data)


class ImageOcrClient:
    """Image识别解析."""

    def __init__(self, account: str, password: str, project_id: int, timeout: int = 30):
        """初始化函数."""
        self.domain = "https://label.ocr.oigit.com"
        self.account = account
        self.password = password
        self.project_id = project_id
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.token = Token.load()
        self.labels = {}
        self.fields = {}

    @property
    def is_logined(self):
        """是否已登录."""
        if self.token:
            return True
        return False

    @property
    def login_header(self):
        """登录头."""
        return {"Authorization": " ".join(["Bearer", self.token])}

    def reset_token(self):
        """重置登录."""
        self.token = Token()
        self.labels = {}
        self.fields = {}

    async def login_when_not_token(self):
        """登录."""
        if self.is_logined:
            return

        await self.login()

    async def login(self):
        """登录接口."""
        url = self.domain + "/api/auth/login"
        data = {
            "password": self.password,
            "username": self.account,
            "grant_type": "password",
        }
        logger.info("开始请求OCR登录")
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(url, data=data) as rsp:
                data = await rsp.read()
                if rsp.status != 200:
                    raise TypeError(f"OCR登录失败 {rsp.status} {data}")

                json_data = await rsp.json()

                if (
                    not isinstance(json_data, dict)
                    or "access_token" not in json_data
                    or not json_data["access_token"]
                ):
                    raise TypeError(f"OCR登录失败 {json_data}")

                self.token = Token(json_data["access_token"])
                self.token.save()

    @hook_logged
    async def get_task_id(self, image_url: str):
        """创建任务并."""
        if not (image_url.startswith("http://") or image_url.startswith("https://")):
            raise TypeError("无效请求地址")

        url = self.domain + f"/api/task/{self.project_id}/create"
        data = {
            "cno": "--",
            "description": "",
            "orderno": "",
            "url": image_url,
        }
        logger.info("开始获取任务信息 %s", image_url)
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(url, json=data, headers=self.login_header) as rsp:
                if rsp.status == 401:
                    raise LoginInvaild(await rsp.text())

                data = await rsp.read()
                if rsp.status != 200:
                    text = await rsp.text()
                    raise TypeError(f"请求失败 {text}")

                json_data = await rsp.json()
                return json_data["taskId"]

    @hook_logged
    async def get_project_info(self) -> None | dict:
        """获取项目信息."""
        logger.info("开始获取项目信息 %s", self.project_id)
        url = self.domain + f"/api/task/bulk/{self.project_id}/labels"
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.get(url, headers=self.login_header) as rsp:
                if rsp.status == 401:
                    raise LoginInvaild(await rsp.text())

                data = await rsp.read()
                if rsp.status != 200:
                    raise TypeError(f"请求失败 {data}")

                json_data = await rsp.json()

                return json_data

    async def load_project_info(self):
        """获取项目信息."""
        if self.fields and self.labels:
            return

        info = await self.get_project_info()
        fields = info.get("fields", [])
        labels = info.get("labels", [])
        self.labels = {i["label"]: i["value"] for i in labels}
        self.fields = {j["fieldId"]: j["label"] for i in fields for j in i["childrens"]}

    @hook_logged
    async def get_task_info(self, task_id) -> None | dict:
        """获取任务."""
        logger.info("开始获取任务信息 %s", task_id)
        url = self.domain + f"/api/task/bulk/{self.project_id}/tasks?task_id={task_id}"
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.get(url, headers=self.login_header) as rsp:
                if rsp.status == 401:
                    raise LoginInvaild(await rsp.text())

                data = await rsp.read()
                if rsp.status != 200:
                    raise TypeError(f"请求失败 {data}")

                json_data = await rsp.json()
                # logger.info(f"获取结果 {json_data}")
                return json_data.get("data", [None])[0]

    async def waitting_task(self, task_id, timeout=None, watting_sleep=5):
        """等待任务."""

        async def __watting_task():
            await client.load_project_info()
            start = time.time()
            while True:
                if time.time() - start > settings.OCR_TIMEOUT:
                    break

                task = await self.get_task_info(task_id)
                if task["status"] not in ["PS_PASSED", "PS_CHECKED"]:
                    logger.info("成功获取任务信息 任务尚未完成 %s", task_id)
                    await asyncio.sleep(watting_sleep)
                    continue

                # 取下标0，因为是图片不存在多个类型
                task = task["datas"][0]
                logger.info("成功获取任务信息 %s", task_id)
                return {
                    "labels": self.labels.get(task["label"], "未知的文件类型"),
                    "fields": [
                        (self.fields.get(word["label"], word["label"]), word["text"])
                        for word in task["annotationWords"]
                    ],
                }

        task = await asyncio.wait_for(__watting_task(), timeout)
        return task


client = ImageOcrClient(
    account=OCR_ACCOUNT, password=OCR_PASSWORD, project_id=OCR_PROJECT
)


async def image_ocr(action_attachment: str, action_input: str):
    """image ocr."""
    url = action_attachment

    task_id = await client.get_task_id(url)
    task = await client.waitting_task(task_id, timeout=300)

    return json.dumps(
        {
            "label": task["labels"],
            "fields": "\n".join(": ".join(i) for i in task["fields"]),
            "question": action_input,
        }
    )


async def search_image_ocr(attachment: str, question: str):
    """查询ocr."""
    logger.info("attachment:%s, question:%s", attachment, question)
    return await image_ocr(attachment, question)
