import asyncio
import dataclasses
import json
import logging
import time

from openai import AsyncOpenAI
from openai.types.beta.thread import Thread
from openai.types.beta.threads import Run
from openai.types.beta.threads.runs.tool_calls_step_details import ToolCall

from app.config import settings
from search_collection import search_factory
from search_image_ocr import search_image_ocr

logger = logging.getLogger("uvicorn.main")

client_ = AsyncOpenAI(
    base_url=settings.BASE_URL,
    api_key=settings.OPENAI_API_KEY,
)


class ChatError(Exception):
    """ChatError"""


class TimeoutRunning(ChatError):
    """TimeoutRunning"""


class ChatIsRunning(ChatError):
    """ChatIsRunning"""


class FailedRunning(ChatError):
    """FailedRunning"""


def client_partial(func, client: AsyncOpenAI):
    async def wrapper_call(*args, **kwargs):
        return await func(client, *args, **kwargs)

    return wrapper_call


@dataclasses.dataclass
class ChatInfo:
    thread: Thread
    assistant_id: str
    # assistant: Assistant
    # run: Run | None

    @property
    def sessin_id(self):
        return self.thread.id[len("thread_") :]


class ChatThread:
    """ChatThread."""

    finished_status = ["cancelled", "failed", "completed", "expired"]

    def __init__(
        self,
        client: AsyncOpenAI,
        info: ChatInfo,
        timeout=120,
        loop_sleep=1,
    ):
        self.info = info
        self.client = client
        self.timeout = timeout
        self.loop_sleep = loop_sleep
        self.running: Run | None = None
        self.available_functions = {
            "search_image_ocr": client_partial(search_image_ocr, client),
            "search_factory": client_partial(search_factory, client),
        }

    async def __chat_tool(self, tool_call: ToolCall):
        """工具调用."""
        logger.info("tool_call: %s", tool_call)

        function_name = tool_call["function"]["name"]
        function_to_call = self.available_functions[function_name]
        arguments = tool_call["function"]["arguments"]

        if arguments.startswith("{") and arguments.endswith("}"):
            try:
                function_args = json.loads(arguments)
            except Exception:
                function_args = {}
        else:
            function_args = {}

        if not isinstance(function_args, dict):
            raise TypeError("")

        logger.info("function_args: %s", function_args)

        if (
            function_name in ["search_image_ocr", "search_factory"]
            and not function_args
        ):
            return None

        function_response = await function_to_call(**function_args)
        logger.info("function_response: %s", function_response)
        return function_response

    async def __processing_step(self, timeout=0):
        """等待子消息."""
        assert self.running
        steps = await self.client.beta.threads.runs.steps.list(
            run_id=self.running.id,
            thread_id=self.info.thread.id,
            timeout=timeout if timeout else self.timeout,
        )
        # 如果有子调用事件
        for step in steps.data:
            if step.step_details.type == "tool_calls":
                messages = []
                for tool in step.step_details.tool_calls:
                    # 如果已经有回复, 不再处理

                    if not isinstance(tool, dict):
                        continue

                    if tool.get("function", {}).get("output"):
                        continue

                    try:
                        function_response = await self.__chat_tool(tool)
                    except Exception as ex:
                        print(ex)
                        function_response = "暂时无法解析此文档，我会收集您的反馈。"

                    if not function_response:
                        continue

                    messages.append(
                        {
                            "tool_call_id": tool["id"],
                            "role": "tool",
                            "name": tool.get("function", {}).get("name", ""),
                            # "content": function_response,
                            "output": function_response,
                        }
                    )

                # TAG - 假定tools不存在同时调用
                if not messages:
                    continue

                await self.client.beta.threads.runs.submit_tool_outputs(
                    thread_id=self.info.thread.id,
                    run_id=self.running.id,
                    tool_outputs=messages,
                )

    async def __create_run_and_waitting_message(
        self, before: str, loop_sleep=0, timeout=0
    ):
        """等待消息."""
        timeout = timeout if timeout else self.timeout
        loop_sleep = loop_sleep if loop_sleep else self.loop_sleep
        self.running = await self.client.beta.threads.runs.create(
            assistant_id=self.info.assistant_id,
            thread_id=self.info.thread.id,
            timeout=timeout,
        )
        start = time.time()

        # 循环等待处理结果
        while True:
            await self.__refresh_running()

            if self.running.status in ["cancelled", "failed", "expired"]:
                raise FailedRunning(
                    f"请求错误[{self.running.last_error.message if self.running.last_error else ''}]"
                )

            if self.running.status in ["completed"]:
                messages = await self.client.beta.threads.messages.list(
                    thread_id=self.info.thread.id, before=before
                )
                if not messages.data:
                    await asyncio.sleep(loop_sleep)
                    continue

                return messages

            # TODO - completed不应该去调用, 注意调用顺序
            # logger.info(f"__processing_step:{timeout}")
            await self.__processing_step(timeout)

            if (time.time() - start) > timeout:
                raise TimeoutRunning()

            await asyncio.sleep(loop_sleep)

    async def __refresh_running(self, timeout=0):
        """刷新running."""
        # 主要处理中时刷新, 完成不用刷新,允许直接创建running
        if not self.running or self.running.status in self.finished_status:
            return

        self.running = await self.client.beta.threads.runs.retrieve(
            run_id=self.running.id,
            thread_id=self.info.thread.id,
            timeout=timeout if timeout else self.timeout,
        )

    async def check_running_status(self):
        """刷新运行状态."""
        await self.__refresh_running()
        if self.running and self.running.status not in self.finished_status:
            raise ChatIsRunning()

    async def push_message_and_waitting_message(
        self, messages: list[str], loop_sleep=0, timeout=0
    ):
        """写入消息,并且等待回复."""
        # 检查是否处理中
        logger.info("thread_id: %s - message: %s", self.info.thread.id, messages)

        await self.check_running_status()

        # 创建消息
        for message in messages:
            message_ = await self.client.beta.threads.messages.create(
                self.info.thread.id, content=message, role="user"
            )

        messages = await self.__create_run_and_waitting_message(
            message_.id, loop_sleep, timeout
        )
        return messages.data[0].content[0].text.value

    async def get_chat_message_list_by_id(
        self,
        thread_id: str,
        query: str,
        timeout: int = 300,
        limit: int = 20,
        loop_sleep: int = 0,
    ):
        """获取聊天所有信息."""
        after = None
        messages = None
        while True:
            _messages = await self.client.beta.threads.messages.list(
                thread_id=thread_id,
                timeout=timeout,
                limit=limit,
                after=after,
            )
            if not _messages.data:
                break

            messages = _messages
            res = [i for i in _messages.data if i.content[-1].text.value == query]
            if res:
                break

            after = _messages.data[0].id

        if not messages:
            return ""

        # 如果消息队列有未处理的消息
        if messages.data[0].role == "assistant":
            res = [
                (index, i)
                for index, i in enumerate(messages.data)
                if i.content[-1].text.value == query
            ]
            if res:
                index = res[0][0]
            else:
                index = -1

            return messages.data[index - 1].content[-1].text.value if index >= 0 else ""

        try:
            await self.check_running_status()
        except ChatIsRunning:
            return ""

        message_ = messages.data[0]
        messages = await self.__create_run_and_waitting_message(
            message_.id, loop_sleep, timeout
        )
        return messages.data[0].content[0].text.value

    @classmethod
    async def create_chat_thread(
        cls,
        client: AsyncOpenAI,
        assistant_id: str,
        messages: list | None = None,
        timeout=60,
        loop_sleep=1,
    ):
        """写入消息,并且等待回复."""
        if messages is None:
            messages = []

        # assistant = await client.beta.assistants.retrieve(assistant_id=assistant_id)
        thread = await client.beta.threads.create(messages=messages)
        info = ChatInfo(assistant_id=assistant_id, thread=thread)
        return cls(client, info, timeout=timeout, loop_sleep=loop_sleep)

    @classmethod
    async def create_chat_thread_by_id(
        cls,
        client: AsyncOpenAI,
        assistant_id: str,
        thread_id: str,
        timeout=60,
        loop_sleep=1,
    ):
        """写入消息,并且等待回复."""
        # assistant = await client.beta.assistants.retrieve(assistant_id=assistant_id)
        thread = await client.beta.threads.retrieve(thread_id=thread_id)
        info = ChatInfo(assistant_id=assistant_id, thread=thread)
        return cls(client, info, timeout=timeout, loop_sleep=loop_sleep)

    @classmethod
    async def create_chat_thread_by_session_id(
        cls,
        client: AsyncOpenAI,
        assistant_id: str,
        session_id: str,
        timeout=60,
        loop_sleep=1,
    ):
        """写入消息,并且等待回复."""
        thread_id = f"thread_{session_id}"
        thread = await client.beta.threads.retrieve(thread_id=thread_id)
        info = ChatInfo(assistant_id=assistant_id, thread=thread)
        return cls(client, info, timeout=timeout, loop_sleep=loop_sleep)


async def chat_main():
    """主函数."""
    messages = [
        {
            "role": "user",
            "content": "Attachment: http://192.168.186.165:9000/testtest/002.png\n\nUpload files attachment.",
        },
        # {
        #     "role": "user",
        #     "content": "question: 请列出文档中包含的全部字段内容？",
        # },
    ]

    thread = await ChatThread.create_chat_thread(
        client_,
        "asst_R8F6CqQ9LehdFKTiDhpZaKFZ",
        messages,
    )

    print(
        f"https://platform.openai.com/playground?assistant={thread.info.assistant_id}&thread={thread.info.thread.id}"
    )

    while True:
        message = input("发送消息:")
        if not message:
            continue

        try:
            rsp = await thread.push_message_and_waitting_message(message)
            print(rsp)
        except ChatIsRunning:
            print("消息运行中")


if __name__ == "__main__":
    print(asyncio.run(chat_main()))
