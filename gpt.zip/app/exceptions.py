# -*- coding: utf-8 -*-
"""
@create: 2023-11-24 12:00:00.

@author: name

@desc: Exception
"""


class CustomizeException(Exception):
    """自定义异常."""

    def __init__(self, msg: str):
        self.status_code = 400
        self.msg = msg


class QueryParamsException(CustomizeException):
    """查询参数异常."""

    def __init__(self, msg: str):
        self.status_code = 400
        self.msg = msg


class TimeoutException(CustomizeException):
    """超时."""

    def __init__(self, msg: str):
        self.status_code = 408
        self.msg = msg


class SessionExpiredException(CustomizeException):
    """Session过期."""

    def __init__(self, msg: str):
        self.status_code = 451
        self.msg = msg


class ThreadException(CustomizeException):
    """线程异常."""

    def __init__(self, msg: str):
        self.status_code = 408
        self.msg = msg
