from io import BytesIO

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse

from app.config import settings
from app.exceptions import QueryParamsException
from app.schemas.chat import MessageRequest

router = APIRouter()


def message_response(answer: str):
    """Stream Response."""
    return StreamingResponse(
        content=BytesIO(answer.encode("utf8")),
        media_type="text/plain",
    )


async def search_local_answer(question: str):
    """查询答案."""
    pass


@router.post("/message")
async def chat_message(body: MessageRequest, req: Request):
    """chat message."""
    _redis = await req.app.state.redis
    print()
    pass
    # if not req.session_id:
    #     thread = await get_thread()
    #     return message_response(thread.info.sessin_id)

    # thread = await get_thread(req.session_id)
    # if not req.query:
    #     raise QueryParamsException(msg="问题为空")

    # if len(req.query) > settings.WORD_LIMIT:
    #     raise QueryParamsException(msg="请简单描述具体想问的问题,字数不能超过512!")
