import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.api.chat import router as chat_router
from app.db.cache import get_redis
from app.exceptions import CustomizeException

logger = logging.getLogger("uvicorn.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """初始化."""
    app.state.redis = await get_redis()
    yield
    await app.state.redis.close()


app = FastAPI(title="Gpt API", version="0.1", lifespan=lifespan)


async def http_exception_handler(_: Request, exc: CustomizeException):
    """Http异常处理."""
    return JSONResponse(status_code=exc.status_code, content={"msg": exc.msg})


app.add_exception_handler(CustomizeException, http_exception_handler)


app.include_router(chat_router, prefix="/chat")
