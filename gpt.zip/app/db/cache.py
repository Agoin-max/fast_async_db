import redis.asyncio as redis

from app.config import settings


async def get_redis():
    """获取缓存."""
    return await redis.from_url(
        settings.REDIS_URL.unicode_string(),
        encoding="utf-8",
        decode_responses=True,
    )
